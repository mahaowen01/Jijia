1. Import Pistol Animset Pro to the project first.
2. Import the additional animations they provided (some directional ones were missing, there is a file for it)
3. Bring this Animator Controller into Unity and put it on a Character.

Should work fine, can be applied to Characters or Enemies.